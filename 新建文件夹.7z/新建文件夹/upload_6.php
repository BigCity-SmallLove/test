<?php

$uploaded_name = $_FILES['file'][ 'name' ];
$uploaded_ext  = substr($uploaded_name,strrpos( $uploaded_name,'.')+1);
if((strtolower( $uploaded_ext ) != "php")
&& (strtolower( $uploaded_ext ) != "asp")
&& (strtolower( $uploaded_ext ) != "jsp"))
{
	if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br />";
  }
  else
  {
  echo "Upload: " . $_FILES["file"]["name"] . "<br />";
  echo "Type: " . $_FILES["file"]["type"] . "<br />";
  echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
  echo "Stored in: " . $_FILES["file"]["tmp_name"];
  }
  
 if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
	  
      echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
      }
}
else
{
	echo "Invalid file";
}


/*
error_reporting(0);

if(isset($_POST['upload']))
{
    $ext_arr = array('flv','swf','mp3','mp4','3gp','zip','rar','gif','jpg','png','bmp');
    $file_ext = substr($_FILES['file']['name'],strrpos($_FILES['file']['name'],".")+1);
    if(in_array($file_ext,$ext_arr))
    {
        $tempFile = $_FILES['file']['tmp_name'];
        // 这句话的$_REQUEST['jieduan']造成可以利用截断上传
        $targetPath = $_SERVER['DOCUMENT_ROOT'].$_REQUEST['jieduan'].rand(10, 99).date("YmdHis").".".$file_ext;
        if(move_uploaded_file($tempFile,$targetPath))
        {
            echo '上传成功'.'<br>';
            echo '路径：'.$targetPath;
        }
        else
        {
            echo("上传失败");
        }

    }
else
{
    echo("上传失败");
}

}
*/
?>
