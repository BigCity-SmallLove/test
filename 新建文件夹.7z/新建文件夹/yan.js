function checkFileExt()
{
 var filename = document.getElementById("file0").value;
 var flag=false;  //设置标志位
 var arr = ["jpg","png","gif"];
 //取出上传文件的扩展名
 var index = filename.lastIndexOf(".");
 var ext = filename.substr(index+1);
 //循环比较
 for(var i=0;i<arr.length;i++)
 {
  if(ext == arr[i])
  {
   flag = true; //一旦找到合适的，立即退出循环
   break;
  }
 }
 //条件判断
 if(flag)
 {
  alert("文件名合法");
 }else
 {
  alert("文件名不合法");
 }
 return flag;
};